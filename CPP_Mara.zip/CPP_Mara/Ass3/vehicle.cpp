#include "vehicle.h"

int Vehicle::total_vehicles = 0;

// constructor
Vehicle::Vehicle() : vtype(Vehicle_Type::TWO_WHEELERS), parking_hrs(3), parkingid(2)
{
    Vehicle_num = new char[10];
    strcpy(Vehicle_num, "MH34QS0012");
    total_vehicles++;
}

//copyconstructor
Vehicle::Vehicle(Vehicle &v)
{
    Vehicle_num = v.Vehicle_num;
    vtype = v.vtype;
    parking_hrs = v.parking_hrs;
    parkingid = v.parkingid;
    total_vehicles++;
}
//operator>>
std::istream &operator>>(std::istream &is, Vehicle &v)
{
    std::cout << "\nEnter the vehicle number : ";
    v.Vehicle_num = new char[10];
    is >> v.Vehicle_num;
    std::cout << "\nEnter the type of vehicle : 0)Two wheeler 1)Four wheeler";
    int temp;
    std::cin >> temp;
    bool t = true;

    switch (temp)
    {
    case 0:
        v.vtype = Vehicle_Type::TWO_WHEELERS;
        ;
        break;
    case 1:
        v.vtype = Vehicle_Type::FOUR_WHEELERS;

        break;

    default:
        std::cout << "Please Enter the Correct Vehicle Type : ";
        std::cin >> v;
        break;
    }

    std::cout << "Enter the parking hours : ";
    is >> v.parking_hrs;

    std::cout << "Enter the Parking Id : ";
    is >> v.parkingid;

    v.total_vehicles++;

    return is;
}
//operator<<
std::ostream &operator<<(std::ostream &os, Vehicle &v)
{
    os << "\nVehicle number : " << v.Vehicle_num;
    os << "  Vehicle type : ";
    switch (v.vtype)
    {
    case 0:
        os << "TWO WHEELER";
        break;
    case 1:
        os << "FOUR WHEELER";
        break;

    default:

        break;
    }

    os << "\nParking Hours : " << v.parking_hrs;

    os << "\nParking Ids : " << v.parkingid;
    v.ShowNumberof_vehicles();

    return os;
}
