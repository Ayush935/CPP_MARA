#include "Parking_Bill.h"

static int bnum = 0;

//constructor
Parking_Bill::Parking_Bill()
{
    bnum++;
    Billnumber = bnum;
    calculateBill();
}
//paraconstructor
Parking_Bill::Parking_Bill(Vehicle &v) : vh(v)
{
    bnum++;
    Billnumber = bnum;
    parking_charges_amt = 0;
    parking_charges_amt = calculateBill();
}
//operator<<
std::ostream &operator<<(std::ostream &os, Parking_Bill &pb)
{
    os << "\nBill Number : " << pb.Billnumber;
    os << pb.vh;
    os << "\nParking amount : " << pb.calculateBill();
    os << "\nParking charges for 2 wheelers : {10,20,30,100}";
    os << "\nParking charges for 4 wheelers : {20,30,40,200}";

    return os;
}
//operator>>
std::istream &operator>>(std::istream &is, Parking_Bill &pb)
{
    bnum++;
    pb.Billnumber = bnum;
    is >> pb.vh;

    return is;
}
//calculating bill
float Parking_Bill::calculateBill()
{

    int phour = vh.parkingHrs();
    float amount = 0;
    //2wheelers
    while (phour > 0 && vh.getVtype() == 0)
    {
        if (phour <= 3)
        {
            amount += 30;
        }
        else if (phour > 3 && vh.parkingHrs() <= 6)
        {
            amount += 60;
        }
        else if (phour > 6 && vh.parkingHrs() <= 12)
        {
            amount += 90;
        }
        else
        {
            amount += 100;
            break;
        }

        phour -= 3;
    }
    //4wheelers
    while (phour > 0 && vh.getVtype() == 1)
    {
        if (phour <= 3)
        {
            amount += 60;
        }
        else if (phour > 3 && vh.parkingHrs() <= 6)
        {
            amount += 90;
        }
        else if (phour > 6 && vh.parkingHrs() <= 12)
        {
            amount += 120;
        }
        else
        {
            amount += 200;
            break;
        }

        phour -= 3;
    }

    return amount;
}
//for searching
bool Parking_Bill::operator==(const char *v)
{
    return !strcmp(v, vh.vehicleNum());
}
//for type matching
bool Parking_Bill::operator==(int n)
{
    return (vh.getVtype() == n);
}