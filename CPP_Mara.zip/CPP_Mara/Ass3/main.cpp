#include "Parking_Bill.h"


//total parking
float total_parking(Parking_Bill *p[], int size)
{
    float sum = 0;

    for (int i = 0; i < size; i++)
    {
        sum += p[i]->calculateBill();
    }

    return sum;
}
//search function
void search(Parking_Bill *p[])
{
    char *vnum = new char[10];
    std::cout << "\nPlease Enter the Vehicle Number you want to search : ";
    std::cin >> vnum;
    for (int i = 0; i < 3; i++)
    {
        if (*p[i] == vnum)
        {
            std::cout << "Vehicle name found ";
            break;
        }
        else
        {
            throw InvalidVnum("Vehicle not found");
        }
    }
}
//number of vehicles
int totalv(Parking_Bill *p[])
{
    int t = 0;
    for (int i = 0; i < 3; i++)
    {
        t++;
    }
    return t;
}
//parking of 2 wheelers
void parkingof2(Parking_Bill *p[])
{
    int tw = 0;
    for (int i = 0; i < 3; i++)
    {
        if (*p[i] == 0)
        {
            tw++;
        }
    }

    std::cout << "\nTotal number of two wheelers : " << tw;
}
//parking of 4 wheelers 
void parkingof4(Parking_Bill *p[])
{
    int fw = 0;
    for (int i = 0; i < 3; i++)
    {
        if (*p[i] == 1)
        {
            fw++;
        }
    }

    std::cout << "\nTotal number of two wheelers : " << fw;
}
int main()
{

    Vehicle v[3];
    Parking_Bill *p[3];
    for (int i = 0; i < 3; i++)
    {
        std::cin >> v[i];
        p[i] = new Parking_Bill(v[i]);
    }

    for (int i = 0; i < 3; i++)
    {
        std::cout << *p[i];
    }

    std::cout << "\nTotal Charges: " << total_parking(p, 3);

    try
    {

        search(p);
    }
    catch (InvalidVnum &i)
    {
        std::cout << "\nError" << i.what();
        search(p);
    }
    catch (std::exception &e)
    {
        std::cout << "\nError " << e.what();
    }

    std::cout << "\nTotal number of vehicle parked : " << totalv(p);

    parkingof2(p);
    parkingof4(p);

    for(int i=0;i<3;i++){
        delete p[i];
    }
}
