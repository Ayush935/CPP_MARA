#ifndef VEHICLE_H
#define VEHICLE_H

#include <iostream>
#include <cstring>

enum Vehicle_Type
{
    TWO_WHEELERS,
    FOUR_WHEELERS
};

class Vehicle
{
    char *Vehicle_num;
    Vehicle_Type vtype;
    int parking_hrs;
    int parkingid;
    static int total_vehicles;

public:
    Vehicle();
    Vehicle(Vehicle &v);
    friend std::istream &operator>>(std::istream &is, Vehicle &v);
    friend std::ostream &operator<<(std::ostream &os, Vehicle &v);

    static void ShowNumberof_vehicles()
    {
        std::cout << total_vehicles;
    };

    char *vehicleNum() { return Vehicle_num; }
    void setVehicleNum(char *vehicleNum) { strcpy(Vehicle_num, vehicleNum); }

    int getVtype() const { return vtype; }
    void setVtype(int n)
    {
        switch (n)
        {
        case 0:
            vtype = Vehicle_Type::TWO_WHEELERS;

            break;
        case 1:
            vtype = Vehicle_Type::FOUR_WHEELERS;
            break;

        default:
            break;
        }
    }

    int parkingHrs() { return parking_hrs; }
    void setParkingHrs(int parkingHrs) { parking_hrs = parkingHrs; }

    int getParkingid() const { return parkingid; }
    void setParkingid(int parkingid_) { parkingid = parkingid_; }
};

#endif // VEHICLE_H
