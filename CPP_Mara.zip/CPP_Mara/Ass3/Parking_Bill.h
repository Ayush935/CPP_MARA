#ifndef PARKING_BILL_H
#define PARKING_BILL_H

#include <iostream>
#include "vehicle.h"

class InvalidVnum : public std::exception
{
    char c[10];

public:
    InvalidVnum(const char *msg)
    {
        strcpy(c, msg);
    }

    const char *what()
    {
        return c;
    }
};

class Parking_Bill
{
    int Billnumber;
    Vehicle vh;
    float parking_charges_amt;
    int parking_charges_2wheelers[4] = {10, 20, 30, 100};
    int parking_charges_4wheelers[4] = {20, 30, 40, 200};

public:
    Parking_Bill();
    Parking_Bill(Vehicle &v);
    friend std::istream &operator>>(std::istream &is, Parking_Bill &pb);
    friend std::ostream &operator<<(std::ostream &os, Parking_Bill &pb);

    float calculateBill();

    Vehicle getVh() { return vh; }
    void setVh(const Vehicle &vh_) { vh = vh_; }

    float parkingChargesAmt() const { return parking_charges_amt; }
    void setParkingChargesAmt(float parkingChargesAmt) { parking_charges_amt = parkingChargesAmt; }

    bool operator==(const char *);

    bool operator==(int n);
};
#endif // PARKING_BILL_H
