#include "Player.h"

int main()
{
    int score[3] = {22, 4, 4};
    Player p1; // object called
    Player p2;
    p2.setScore(score);

    std::cout << p1 << std::endl; // operator overloading <<
    std::cout << p2 << std::endl;

    // compare average score
    if (p1 < p2)
    {
        std::cout << "Player P2 have less average score" << std::endl;
    }
    else
    {
        std::cout << "Player P1 have less average score" << std::endl;
    }

    // add average score of two players
    double sum = p1 + p2;
    std::cout << "Addition of Average Score of two players " << sum << std::endl;

    // compare two players number of matches played
    if (p1 == p2)
    {
        std::cout << "Players Played same number of matches" << std::endl;
    }
    else
    {
        std::cout << "Players have not Played same number of matches" << std::endl;
    }
}