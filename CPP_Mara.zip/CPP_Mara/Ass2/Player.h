#ifndef PLAYER_H
#define PLAYER_H

#include <iostream>
#include <cstring>

class Player
{
    int PlayerId; // data members
    char *Playername;
    float Playerage;
    int Numberofmatchesplayed;
    int Playerrank;
    int *Score;
    static int num;

public:
    Player(); // default constructor

    int getplayerId() const { return PlayerId; } // getter setter functions
    void setPlayerId(int &playerId) { PlayerId = playerId; }

    float getplayerage() const { return Playerage; }
    void setPlayerage(float &playerage) { Playerage = playerage; }

    int getnumberofmatchesplayed() const { return Numberofmatchesplayed; }
    void setNumberofmatchesplayed(int &numberofmatchesplayed) { Numberofmatchesplayed = numberofmatchesplayed; }

    int getplayerrank() const { return Playerrank; }
    void setPlayerrank(int playerrank) { Playerrank = playerrank; }

    char *playername() const { return Playername; }
    void setPlayername(char *playername) { strcpy(Playername, playername); }

    int *score() const { return Score; }
    void setScore(int *score)
    {
        for (int i = 0; i < 3; i++)
        {
            Score[i] = score[i];
        }
    }

    double const Calculateaveragescore(); // calculate average score
    bool operator<(Player &);             // operator overloading for <
    bool operator==(const Player &);      // operator overloading for ==
    double operator+(Player &);           // operator overloading for +

    friend std::ostream &operator<<(std::ostream &, Player &); // operator overloading for <<

    ~Player();
};

#endif // PLAYER_H
